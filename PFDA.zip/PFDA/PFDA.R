# NAME
# TP

############### LOAD THE PACKEAGES ############### 

install.packages("tidyverse")
install.packages("ggplot2")
install.packages("MASS")
install.packages("broom")
install.packages("vcd")
install.packages("dplyr")
install.packages("ggmosaic")
install.packages("forcats")

############### LOAD LIBRARIES ###################

library(tidyverse)
library(ggplot2)
library(MASS)
library(broom)
library(vcd)
library(dplyr)
library(ggmosaic)
library(forcats)

############### IMPORT DATASET ##################

dataReader <- read.csv("C:/Yan/PFDA/Data/employee_attrition.csv")
View(dataReader)

############### ASSIGN THE HEADERS ###############

names(dataReader) <- c("EmployeeID", "recorddate_key", "birthdate_key", 
                       "orighiredate_key", "terminationdate_key",
                       "age", "length_of_service", "city_name", 
                       "department_name", "job_title", "store_name",
                       "gender_short", "gender_full", "termreason_desc", 
                       "termtype_desc", "STATUS_YEAR", "STATUS",
                       "BUSINESS_UNIT")

############### DATA MANUPULATION ############### 

# Question 1: Does age play a significant role in the employment status of an employee (ACTIVE/TERMINATED)?
# Analysis 1-1: Descriptive Analysis
# Count the number of ACTIVE and TERMINATED employees in each age group
dataReader %>%
  group_by(age, STATUS) %>%
  summarise(count = n(), .groups = "keep") -> count_data

print(count_data)

# Plot a bar chart showing the number of employees in each status category for each age group
ggplot(data = count_data, aes(x = age, y = count, fill = STATUS)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(x = "Age", y = "Count", fill = "Status", title = "Number of Employees per Status for each Age Group") +
  theme_minimal()

# Analysis 1-2: Chi-square Test
# Create a contingency table of age and status
contingency_table <- table(dataReader$age, dataReader$STATUS)

# Perform Chi-square test
chisq_test <- chisq.test(contingency_table)

# Print the result of Chi-square test
print(chisq_test)

# Change STATUS as a factor, and reorder its levels by the counts in each category
dataReader$STATUS <- fct_infreq(dataReader$STATUS)

# Create a bar plot
ggplot(dataReader, aes(x = age, fill = STATUS)) +
  geom_bar(position = "dodge") +
  theme_minimal() +
  labs(title = "Number of Employees by Status and Age", 
       x = "Age", 
       y = "Number of Employees", 
       fill = "Status") +
  theme(plot.title = element_text(hjust = 0.5))

# Analysis 1-3: Logistic Regression
# Assume that the status variable is binary, where "ACTIVE" = 1 and "TERMINATED" = 0
dataReader$status_bin <- ifelse(dataReader$STATUS == "ACTIVE", 1, 0)
logistic_model <- glm(status_bin ~ age, data = dataReader, family = binomial())

# Print the summary of the model
summary(logistic_model)

# Collect tidy summaries of model coefficients
tidy(logistic_model)

# Extract fitted values and create a new data frame for plotting
plot_data <- data.frame(
  age = dataReader$age,
  fitted = fitted(logistic_model)
)

# Create a plot
ggplot(plot_data, aes(x = age, y = fitted)) +
  geom_point() +
  geom_smooth(method = "glm", method.args = list(family = "binomial"), se = FALSE) +
  labs(x = "Age", y = "Fitted values", title = "Logistic Regression of Status on Age") +
  theme_minimal()

# Question 2: What is the distribution of job titles among males and females in the company?
# Analysis 2-1: Descriptive Analysis
# Only use the top 10 most common job titles
top_jobs <- names(sort(table(dataReader$job_title), decreasing = TRUE)[1:10])
data_subset <- dataReader[dataReader$job_title %in% top_jobs,]

# Create a contingency table of gender and job title for the subsetted data        
gender_job_table <- table(data_subset$gender_full, data_subset$job_title)

# Analysis 2-2: Chi-square Test
# Perform Chi-square test
chisq_test <- chisq.test(gender_job_table)

print(chisq_test)

# Create a mosaic plot of gender and job title
vcd::mosaic(gender_job_table, 
            main = "Mosaic Plot of Job Title and Gender (Top 10 Jobs)", 
            xlab = "Gender", 
            ylab = "Job Title", 
            shade = TRUE)

# Plotting with ggplot2 & ggmosaic
ggplot(data = gender_job_df, aes(x = job_title, weight = count, fill = gender)) +
  geom_mosaic() +
  labs(x = "Job Title", y = "Proportion", fill = "Gender") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  ggtitle("Distribution of Gender across Top 10 Job Titles")

# Analysis 2-3: Logistic Regression###
# Assume that the gender variable is binary, where "MALE" = 1 and "FEMALE" = 0
# Transform the data into a binary form
dataReader$gender_bin <- ifelse(dataReader$gender_full == "MALE", 1, 0)

# Fit the logistic regression model
logistic_model_gender <- glm(gender_bin ~ job_title, data = dataReader, family = binomial())

# Generate a summary of the model
summary(logistic_model_gender)

# Create a tidy output of the model
library(broom)
tidy_output <- tidy(logistic_model_gender)

# Calculate Odds Ratios from coefficients
tidy_output$odds_ratio <- exp(tidy_output$estimate)

# Plot Odds Ratios with ggplot2
library(ggplot2)
ggplot(tidy_output, aes(x = reorder(term, odds_ratio), y = odds_ratio)) +
  geom_point() +
  coord_flip() +  # flip coordinates for better visualization
  labs(y = "Odds Ratio", x = "Job Title",
       title = "Odds Ratios of Job Titles in Predicting Male Gender") +
  theme_minimal()

# Question 3: Do the employees from different cities have different lengths of service?
# Analysis 3-1: Descriptive Analysis          
# Calculate the mean length of service for employees in each city
city_service <- dataReader %>%
  group_by(city_name) %>%
  summarise(mean_service = mean(length_of_service), .groups = "keep")

print(city_service)

# Plot a box plot showing the distribution of length of service for each city
ggplot(data = dataReader, aes(x = reorder(city_name, -length_of_service), y = length_of_service)) +
  geom_boxplot() +
  coord_flip() +
  labs(x = "City", y = "Length of Service",
       title = "Distribution of Length of Service for each City") +
  theme_minimal()

# Analysis 3-2: ANOVA Test
# Only use the top 10 cities with the most employees
top_cities <- names(sort(table(dataReader$city_name), decreasing = TRUE)[1:10])
data_subset <- dataReader[dataReader$city_name %in% top_cities,]

# Create a boxplot of length of service by city name for the subsetted data
ggplot(data_subset, aes(x = city_name, y = length_of_service)) +
  geom_boxplot() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Boxplot of Length of Service by City (Top 10 Cities)",
       x = "City Name",
       y = "Length of Service")

# Analysis 3-3: Linear Regression 
linear_model <- lm(length_of_service ~ city_name, data = dataReader)
summary(linear_model)
tidy(linear_model)
# Prepare data
tidy_lm <- tidy(linear_model)

# Create coefficient plot
ggplot(tidy_lm, aes(x = reorder(term, estimate), y = estimate)) +
  geom_pointrange(aes(ymin = estimate - std.error, ymax = estimate + std.error)) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  coord_flip() +
  labs(title = "Coefficient Plot",
       x = "City Name",
       y = "Estimated Coefficients")

# Question 4: Is there a significant difference in length of service between employees who are still active
# Analysis 4-1: Descriptive Analysis
# Calculate the mean length of service for active and terminated employees
active_employees <- dataReader %>%
  filter(STATUS == "ACTIVE") %>%
  summarise(mean_length_of_service = mean(length_of_service))
print(active_employees)

terminated_employees <- dataReader %>%
  filter(STATUS == "TERMINATED") %>%
  summarise(mean_length_of_service = mean(length_of_service))
print(terminated_employees)

# Plot a histogram showing the distribution of length of service for each group
ggplot(dataReader, aes(x=length_of_service, fill=STATUS)) +
  geom_histogram(position="identity", alpha=0.5, bins=30) +
  labs(x="Length of Service", y="Count", fill="Status", title="Length of Service Distribution by Status") +
  theme_minimal()

# Analysis 4-2: T-Test
# Test the null hypothesis that the mean length of service is the same for active and terminated employees
t_test <- t.test(dataReader$length_of_service ~ dataReader$STATUS)
print(t_test)

# PLOT
ggplot(dataReader, aes(x=STATUS, y=length_of_service, fill=STATUS)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title="Boxplot of Length of Service by Status",
       x="Status",
       y="Length of Service",
       fill="Status")

# Analysis 4-3: Logistic Regression
# Fit a logistic regression model using status as the response and length of service as the predictor
dataReader$status_bin <- ifelse(dataReader$STATUS == "ACTIVE", 1, 0)
logistic_model <- glm(status_bin ~ length_of_service, data = dataReader, family = binomial())
summary(logistic_model)
tidy(logistic_model)

# Plot the data with jitter
ggplot(dataReader, aes(x=length_of_service, y=status_bin)) +
  geom_jitter(alpha=0.4, width = 0.3) +
# Add logistic regression line
geom_smooth(method="glm", method.args=list(family="binomial"), se=FALSE, color="blue", linetype="dashed") +
theme_minimal() +
labs(title="Logistic Regression of Status on Length of Service",
     x="Length of Service",
     y="Status (Active=1, Terminated=0)")

# Question 5: Are male and female employees distributed evenly across different departments?
# Analysis 5-1: Descriptive Analysis
# Count the number of males and females in each department 
gender_count <- dataReader %>%
  group_by(department_name, gender_short) %>%
  summarise(count = n(), .groups = "keep")
print(gender_count)

# Create a bar plot
gender_count %>%
  ggplot(aes(x = department_name, y = count, fill = gender_short)) +
  geom_bar(stat = "identity", position = "dodge") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = "Department", y = "Count", fill = "Gender", 
       title = "Number of Males and Females in Each Department")

# Analysis 5-2: Chi-square Test
# Test the null hypothesis that gender is independent of department
contingency_table <- table(dataReader$gender_short, dataReader$department_name)
chisq_test <- chisq.test(contingency_table)
print(chisq_test)

# Visualize the result using a mosaic plot
mosaicplot(contingency_table, main="Mosaic Plot of Gender and Department", 
           xlab="Department", ylab="Gender", color=c("dodgerblue3","darkorange2"), las=1)

# Association plot to display the residuals from the chi-squared test
assocplot(contingency_table, main="Association Plot of Gender and Department")

# Analysis 5-3: Logistic Regression
# Fit a logistic regression model using gender as the response and department as the predictor
dataReader$gender_bin <- ifelse(dataReader$gender_short == "M", 1, 0)
logistic_model <- glm(gender_bin ~ department_name, data = dataReader, family = binomial())
summary(logistic_model)
tidy(logistic_model)
s
# Get tidy output
tidy_output <- broom::tidy(logistic_model)

# Plot coefficients
ggplot(tidy_output, aes(x = estimate, y = reorder(term, estimate))) +
  geom_vline(xintercept = 0, color = "grey", linetype = "dashed") +
  geom_point() +
  geom_errorbarh(aes(xmin = estimate - std.error * 1.96, xmax = estimate + std.error * 1.96), height = .2) +
  labs(y = "Term", x = "Estimate") +
  theme_minimal()






